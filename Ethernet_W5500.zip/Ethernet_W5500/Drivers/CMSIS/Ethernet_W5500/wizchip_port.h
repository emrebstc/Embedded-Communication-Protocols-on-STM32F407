#ifndef INC_WIZCHIP_PORT_H_
#define INC_WIZCHIP_PORT_H_


int W5500_Init(void);


#endif /* INC_WIZCHIP_PORT_H_ */
