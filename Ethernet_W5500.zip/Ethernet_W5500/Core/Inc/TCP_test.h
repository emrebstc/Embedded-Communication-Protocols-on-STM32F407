/*
 * TCP_test.h
 *
 *  Created on: Nov 16, 2025
 *      Author: Emre
 */

#ifndef INC_TCP_TEST_H_
#define INC_TCP_TEST_H_

void TCP_Server_Process(void);

#endif /* INC_TCP_TEST_H_ */
